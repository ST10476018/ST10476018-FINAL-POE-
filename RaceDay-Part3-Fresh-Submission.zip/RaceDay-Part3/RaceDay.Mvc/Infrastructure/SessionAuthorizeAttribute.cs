using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
namespace RaceDay.Mvc.Infrastructure;
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public sealed class SessionAuthorizeAttribute(string? role = null) : Attribute, IAuthorizationFilter
{
 public void OnAuthorization(AuthorizationFilterContext context) {
  var session = context.HttpContext.Session;
  var userId = session.GetInt32("UserId");
  var actualRole = session.GetString("Role");
  if (userId is null || (role is not null && actualRole != role)) {
   context.Result = new RedirectToActionResult("Login", "Account", new { returnUrl = context.HttpContext.Request.Path });
  }
 }
}
