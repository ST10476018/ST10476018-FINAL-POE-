using System.ComponentModel.DataAnnotations;
namespace RaceDay.Mvc.Models;

public sealed class LoginVm {
 [Required, EmailAddress] public string Email { get; set; } = "";
 [Required, DataType(DataType.Password)] public string Password { get; set; } = "";
}
public sealed class RegisterVm {
 [Required, StringLength(120, MinimumLength=2)] public string FullName { get; set; } = "";
 [Required, EmailAddress] public string Email { get; set; } = "";
 [Required, MinLength(8), DataType(DataType.Password)] public string Password { get; set; } = "";
 [Required] public string Role { get; set; } = "Participant";
}
public sealed class EventVm {
 public int Id { get; set; }
 [Required, StringLength(150)] public string Name { get; set; } = "";
 public string Description { get; set; } = "";
 [Required] public DateTime EventDate { get; set; } = DateTime.Today.AddDays(14);
 [Required] public string Location { get; set; } = "";
 [Range(0.1, 1000)] public decimal DistanceKm { get; set; }
 [Required] public string EventType { get; set; } = "run";
 public string? BannerImageUrl { get; set; }
 public IFormFile? BannerFile { get; set; }
}
public sealed class CategoryVm {
 [Required] public string Name { get; set; } = "";
 public string? AgeGroup { get; set; }
 [Range(0.1, 1000)] public decimal? DistanceKm { get; set; }
}
public sealed class EnrolVm { public int CategoryId { get; set; } }
public sealed class ResultVm {
 [Required] public int ParticipantId { get; set; }
 public string? FinishTime { get; set; }
 [Range(1, 100000)] public int FinishPosition { get; set; }
}
public sealed class ApiUser { public int Id {get;set;} public string FullName {get;set;}=""; public string Email {get;set;}=""; public string Role {get;set;}=""; }

public sealed class EventDto { public int Id {get;set;} public string Name {get;set;}=""; public string Description {get;set;}=""; public DateTime EventDate {get;set;} public string Location {get;set;}=""; public decimal DistanceKm {get;set;} public string EventType {get;set;}=""; public int OrganizerId {get;set;} public string? BannerImageUrl {get;set;} public List<EventCategoryDto> Categories {get;set;}=[]; }
public sealed class EventCategoryDto { public int CategoryId {get;set;} public string Name {get;set;}=""; public string? AgeGroup {get;set;} public decimal? DistanceKm {get;set;} }
public sealed class EnrolmentDto { public int Id {get;set;} public int EventId {get;set;} public string EventName {get;set;}=""; public int ParticipantId {get;set;} public string ParticipantName {get;set;}=""; public int CategoryId {get;set;} public string CategoryName {get;set;}=""; public DateTime EnrolledAtUtc {get;set;} }
public sealed class ResultDto { public int ParticipantId {get;set;} public string ParticipantName {get;set;}=""; public TimeSpan? FinishTime {get;set;} public int FinishPosition {get;set;} }
