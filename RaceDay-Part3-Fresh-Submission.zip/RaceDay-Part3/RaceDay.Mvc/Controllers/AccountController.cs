using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
public sealed class AccountController(RaceDayApiClient api) : Controller
{
 [HttpGet] public IActionResult Login(string? returnUrl=null) { ViewBag.ReturnUrl=returnUrl; return View(); }
 [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> Login(LoginVm model, string? returnUrl=null) {
  ViewBag.ReturnUrl=returnUrl;
  if(!ModelState.IsValid) return View(model);
  try {
   var user=await api.LoginAsync<ApiUser>(model.Email, model.Password);
   if(user is null) { ModelState.AddModelError("", "Email or password is incorrect."); return View(model); }
   HttpContext.Session.SetInt32("UserId",user.Id); HttpContext.Session.SetString("Name",user.FullName); HttpContext.Session.SetString("Role",user.Role);
   return RedirectToLocal(returnUrl) ?? RedirectToAction("Index", user.Role=="Organizer"?"Organizer":"Participant");
  } catch { ModelState.AddModelError("", "Unable to contact RaceDay API. Check that the API is running."); return View(model); }
 }
 [HttpGet] public IActionResult Register() => View();
 [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> Register(RegisterVm model) {
  if(!ModelState.IsValid) return View(model);
  if(model.Role is not ("Organizer" or "Participant")) { ModelState.AddModelError(nameof(model.Role),"Select a valid account type."); return View(model); }
  try {
   if(!await api.RegisterAsync(model.FullName,model.Email,model.Password,model.Role)) { ModelState.AddModelError("", "Registration failed. The email may already be registered or the password may not meet the API rules."); return View(model); }
   TempData["Success"]="Account created. Please sign in.";
   return RedirectToAction(nameof(Login));
  } catch { ModelState.AddModelError("", "Unable to contact RaceDay API."); return View(model); }
 }
 [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> Logout() {
  try { await api.SendAsync<object>(HttpMethod.Post,"/api/auth/logout"); } catch { }
  HttpContext.Session.Clear(); return RedirectToAction("Index","Home");
 }
 private IActionResult? RedirectToLocal(string? url) => !string.IsNullOrEmpty(url) && Url.IsLocalUrl(url) ? Redirect(url) : null;
}
