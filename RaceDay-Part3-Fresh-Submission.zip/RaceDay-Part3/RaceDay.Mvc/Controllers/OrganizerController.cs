using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Infrastructure;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
[SessionAuthorize("Organizer")]
public sealed class OrganizerController(RaceDayApiClient api) : Controller
{
 public async Task<IActionResult> Index() {
  try {
   var me=await api.GetAsync<ApiUser>("/api/auth/me");
   var all=await api.GetAsync<List<EventDto>>("/api/events/") ?? [];
   var mine=all.Where(e=>e.OrganizerId==HttpContext.Session.GetInt32("UserId")).ToList();
   var counts=new Dictionary<int,int>();
   foreach(var e in mine) { var rows=await api.GetAsync<List<EnrolmentDto>>($"/api/enrolments/event/{e.Id}"); counts[e.Id]=rows?.Count??0; }
   ViewBag.Counts=counts; ViewBag.Total=counts.Values.Sum(); ViewBag.Upcoming=mine.Count(e=>e.EventDate>=DateTime.Today);
   return View(mine);
  } catch(Exception ex) { TempData["Error"]="Could not load dashboard: "+Safe(ex); return View(new List<EventDto>()); }
 }
 public async Task<IActionResult> Events() {
  try { var all=await api.GetAsync<List<EventDto>>("/api/events/")??[]; return View(all.Where(e=>e.OrganizerId==HttpContext.Session.GetInt32("UserId")).ToList()); }
  catch { TempData["Error"]="Could not load events. Check the API."; return View(new List<EventDto>()); }
 }
 [HttpGet] public IActionResult Create() => View(new EventVm());
 [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> Create(EventVm model) {
  if(!ModelState.IsValid) return View(model);
  try {
   var created=await api.SendAsync<EventDto>(HttpMethod.Post,"/api/events/",new {model.Name,model.Description,model.EventDate,model.Location,model.DistanceKm,model.EventType});
   if(created is null) throw new Exception("The API did not return the created event.");
   if(model.BannerFile is {Length:>0} && !await api.UploadBannerAsync(created.Id,model.BannerFile)) TempData["Error"]="Event created, but the banner upload failed.";
   TempData["Success"]="Event created successfully."; return RedirectToAction(nameof(Events));
  } catch(Exception ex) { ModelState.AddModelError("",Safe(ex)); return View(model); }
 }
 [HttpGet] public async Task<IActionResult> Edit(int id) {
  try { var e=await api.GetAsync<EventDto>($"/api/events/{id}"); if(e is null || e.OrganizerId!=HttpContext.Session.GetInt32("UserId")) return NotFound(); return View(new EventVm{Id=e.Id,Name=e.Name,Description=e.Description,EventDate=e.EventDate,Location=e.Location,DistanceKm=e.DistanceKm,EventType=e.EventType,BannerImageUrl=e.BannerImageUrl}); }
  catch { return NotFound(); }
 }
 [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> Edit(EventVm model) {
  if(!ModelState.IsValid) return View(model);
  try {
   await api.SendAsync<EventDto>(HttpMethod.Put,$"/api/events/{model.Id}",new {model.Name,model.Description,model.EventDate,model.Location,model.DistanceKm,model.EventType});
   if(model.BannerFile is {Length:>0} && !await api.UploadBannerAsync(model.Id,model.BannerFile)) TempData["Error"]="Event updated, but banner upload failed.";
   TempData["Success"]="Event updated."; return RedirectToAction(nameof(Events));
  } catch(Exception ex) { ModelState.AddModelError("",Safe(ex)); return View(model); }
 }
 [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> Delete(int id) {
  try { await api.SendAsync<object>(HttpMethod.Delete,$"/api/events/{id}"); TempData["Success"]="Event deleted."; }
  catch(Exception ex) { TempData["Error"]=Safe(ex); }
  return RedirectToAction(nameof(Events));
 }
 public async Task<IActionResult> Categories(int id) {
  try {
   var e=await api.GetAsync<EventDto>($"/api/events/{id}");
   if(e is null || e.OrganizerId!=HttpContext.Session.GetInt32("UserId")) return NotFound();
   ViewBag.Event=e; ViewBag.AllCategories=await api.GetAsync<List<CategoryDto>>("/api/categories/")??[];
   return View(e.Categories);
  } catch { return NotFound(); }
 }
 [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> AddCategory(int id, CategoryVm model) {
  if(!ModelState.IsValid) { TempData["Error"]="Enter a valid category name and distance."; return RedirectToAction(nameof(Categories),new{id}); }
  try {
   var cat=await api.SendAsync<CategoryDto>(HttpMethod.Post,"/api/categories/",new {model.Name,model.AgeGroup,model.DistanceKm});
   if(cat is null) throw new Exception("Category was not created.");
   await api.SendAsync<object>(HttpMethod.Post,$"/api/events/{id}/categories/{cat.Id}");
   TempData["Success"]="Category added to event.";
  } catch(Exception ex) { TempData["Error"]=Safe(ex); }
  return RedirectToAction(nameof(Categories),new{id});
 }
 public async Task<IActionResult> Enrolments(int id) {
  try {
   var e=await api.GetAsync<EventDto>($"/api/events/{id}");
   if(e is null || e.OrganizerId!=HttpContext.Session.GetInt32("UserId")) return NotFound();
   ViewBag.Event=e; return View(await api.GetAsync<List<EnrolmentDto>>($"/api/enrolments/event/{id}")??[]);
  } catch { TempData["Error"]="Unable to load enrolments."; return RedirectToAction(nameof(Events)); }
 }
 public async Task<IActionResult> Results(int id) {
  try {
   var e=await api.GetAsync<EventDto>($"/api/events/{id}");
   if(e is null || e.OrganizerId!=HttpContext.Session.GetInt32("UserId")) return NotFound();
   ViewBag.Event=e; ViewBag.Enrolments=await api.GetAsync<List<EnrolmentDto>>($"/api/enrolments/event/{id}")??[];
   return View(await api.GetAsync<List<ResultDto>>($"/api/results/events/{id}")??[]);
  } catch { TempData["Error"]="Unable to load results."; return RedirectToAction(nameof(Events)); }
 }
 [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> SaveResult(int id, ResultVm model) {
  if(!ModelState.IsValid) { TempData["Error"]="Enter a valid participant and finishing position."; return RedirectToAction(nameof(Results),new{id}); }
  try { await api.SendAsync<object>(HttpMethod.Post,$"/api/results/events/{id}",model); TempData["Success"]="Result saved."; }
  catch(Exception ex) { TempData["Error"]=Safe(ex); }
  return RedirectToAction(nameof(Results),new{id});
 }
 private static string Safe(Exception ex) => ex is ApiException ? "The API rejected the request. Check the information and try again." : "The request could not be completed. Check the API connection and try again.";
}
public sealed class CategoryDto { public int Id {get;set;} public string Name {get;set;}=""; public string? AgeGroup {get;set;} public decimal? DistanceKm {get;set;} }
