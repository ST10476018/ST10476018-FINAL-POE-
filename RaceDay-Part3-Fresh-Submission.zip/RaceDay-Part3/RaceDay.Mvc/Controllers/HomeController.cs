using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Services;
using RaceDay.Mvc.Models;
namespace RaceDay.Mvc.Controllers;
public sealed class HomeController(RaceDayApiClient api) : Controller
{
 public async Task<IActionResult> Index() {
  try { var events=await api.GetAsync<List<EventDto>>("/api/events/") ?? []; return View(events.Where(e=>e.EventDate>=DateTime.Today).ToList()); }
  catch { ViewBag.ApiUnavailable=true; return View(new List<EventDto>()); }
 }
 public IActionResult Error() => View();
}
