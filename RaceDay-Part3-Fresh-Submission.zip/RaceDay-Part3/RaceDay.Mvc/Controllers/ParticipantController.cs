using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Infrastructure;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
public sealed class ParticipantController(RaceDayApiClient api) : Controller
{
 [SessionAuthorize("Participant")]
 public async Task<IActionResult> Index(string? type, string? q) {
  ViewBag.Type=type; ViewBag.Query=q;
  try {
   var all=await api.GetAsync<List<EventDto>>("/api/events/")??[];
   var upcoming=all.Where(e=>e.EventDate>=DateTime.Today);
   if(!string.IsNullOrWhiteSpace(type)) upcoming=upcoming.Where(e=>e.EventType.Equals(type,StringComparison.OrdinalIgnoreCase));
   if(!string.IsNullOrWhiteSpace(q)) upcoming=upcoming.Where(e=>e.Name.Contains(q,StringComparison.OrdinalIgnoreCase)||e.Location.Contains(q,StringComparison.OrdinalIgnoreCase));
   return View(upcoming.ToList());
  } catch { TempData["Error"]="Unable to load events. Check that the API is running."; return View(new List<EventDto>()); }
 }
 public async Task<IActionResult> Details(int id) {
  try { var e=await api.GetAsync<EventDto>($"/api/events/{id}"); return e is null?NotFound():View(e); }
  catch { return NotFound(); }
 }
 [SessionAuthorize("Participant"), HttpPost, ValidateAntiForgeryToken]
 public async Task<IActionResult> Enrol(int id,int categoryId) {
  try { await api.SendAsync<object>(HttpMethod.Post,$"/api/enrolments/{id}",new{categoryId}); TempData["Success"]="Your enrolment has been recorded."; }
  catch(ApiException ex) { TempData["Error"]=ex.StatusCode==System.Net.HttpStatusCode.Conflict?"You are already enrolled in this event.":"Unable to enrol. Check that the selected category is available."; }
  catch { TempData["Error"]="Unable to contact the RaceDay API."; }
  return RedirectToAction(nameof(Details),new{id});
 }
 [SessionAuthorize("Participant")]
 public async Task<IActionResult> MyEvents() {
  try { ViewBag.Results=await api.GetAsync<List<ParticipantResultDto>>("/api/results/mine")??[]; return View(await api.GetAsync<List<EnrolmentDto>>("/api/enrolments/mine")??[]); }
  catch { TempData["Error"]="Unable to load your enrolments."; return View(new List<EnrolmentDto>()); }
 }
}
public sealed class ParticipantResultDto { public int EventId {get;set;} public string EventName {get;set;}=""; public TimeSpan? FinishTime {get;set;} public int FinishPosition {get;set;} }
