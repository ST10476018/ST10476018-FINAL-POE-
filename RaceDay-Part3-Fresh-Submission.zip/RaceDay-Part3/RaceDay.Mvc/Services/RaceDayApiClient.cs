using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Http;

namespace RaceDay.Mvc.Services;

public sealed class RaceDayApiClient(HttpClient http, IHttpContextAccessor accessor)
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);
    private ISession Session => accessor.HttpContext!.Session;
    private const string CookieKey = "ApiSessionCookie";

    private void ApplyCookie()
    {
        http.DefaultRequestHeaders.Remove("Cookie");
        var cookie = Session.GetString(CookieKey);
        if (!string.IsNullOrWhiteSpace(cookie)) http.DefaultRequestHeaders.TryAddWithoutValidation("Cookie", cookie);
    }

    public async Task<T?> GetAsync<T>(string path)
    {
        ApplyCookie();
        using var response = await http.GetAsync(path);
        return await ReadAsync<T>(response);
    }

    public async Task<T?> SendAsync<T>(HttpMethod method, string path, object? body = null)
    {
        ApplyCookie();
        using var request = new HttpRequestMessage(method, path);
        if (body is not null) request.Content = new StringContent(JsonSerializer.Serialize(body, JsonOptions), Encoding.UTF8, "application/json");
        using var response = await http.SendAsync(request);
        return await ReadAsync<T>(response);
    }

    public async Task<T?> LoginAsync<T>(string email, string password)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, "/api/auth/login") {
            Content = new StringContent(JsonSerializer.Serialize(new { email, password }, JsonOptions), Encoding.UTF8, "application/json")
        };
        using var response = await http.SendAsync(request);
        if (!response.IsSuccessStatusCode) return default;
        if (response.Headers.TryGetValues("Set-Cookie", out var cookies))
        {
            var raw = cookies.FirstOrDefault();
            if (!string.IsNullOrEmpty(raw)) Session.SetString(CookieKey, raw.Split(';', 2)[0]);
        }
        return await response.Content.ReadFromJsonAsync<T>(JsonOptions);
    }

    public async Task<bool> RegisterAsync(string fullName, string email, string password, string role)
    {
        using var response = await http.PostAsJsonAsync("/api/auth/register", new { fullName, email, password, role }, JsonOptions);
        return response.IsSuccessStatusCode;
    }

    public async Task<bool> UploadBannerAsync(int eventId, IFormFile file)
    {
        ApplyCookie();
        using var content = new MultipartFormDataContent();
        await using var stream = file.OpenReadStream();
        using var fileContent = new StreamContent(stream);
        fileContent.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);
        content.Add(fileContent, "file", Path.GetFileName(file.FileName));
        using var response = await http.PostAsync($"/api/events/{eventId}/banner", content);
        return response.IsSuccessStatusCode;
    }

    private static async Task<T?> ReadAsync<T>(HttpResponseMessage response)
    {
        if (response.StatusCode == HttpStatusCode.NoContent) return default;
        if (!response.IsSuccessStatusCode) throw new ApiException(await response.Content.ReadAsStringAsync(), response.StatusCode);
        return await response.Content.ReadFromJsonAsync<T>(JsonOptions);
    }

    public void ClearApiCookie() => Session.Remove(CookieKey);
}

public sealed class ApiException(string message, HttpStatusCode statusCode) : Exception(message)
{
    public HttpStatusCode StatusCode { get; } = statusCode;
}
