$ErrorActionPreference = 'Stop'

Write-Host 'RaceDay Part 3 - local development tools setup' -ForegroundColor Cyan

function Test-DotNet8 {
    $sdks = dotnet --list-sdks 2>$null
    return ($sdks | Where-Object { $_ -match '^8\.0\.' }).Count -gt 0
}

if (Get-Command dotnet -ErrorAction SilentlyContinue) {
    if (Test-DotNet8) {
        Write-Host '.NET 8 SDK is already installed.' -ForegroundColor Green
    } else {
        Write-Warning '.NET is installed, but no .NET 8 SDK was found.'
        if (Get-Command winget -ErrorAction SilentlyContinue) {
            $answer = Read-Host 'Install Microsoft .NET 8 SDK using winget? (Y/N)'
            if ($answer -match '^(Y|YES)$') { winget install --id Microsoft.DotNet.SDK.8 --exact --source winget }
        } else {
            Write-Host 'Install .NET 8 SDK manually: https://dotnet.microsoft.com/download/dotnet/8.0'
        }
    }
} else {
    Write-Warning '.NET SDK was not found.'
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        $answer = Read-Host 'Install Microsoft .NET 8 SDK using winget? (Y/N)'
        if ($answer -match '^(Y|YES)$') { winget install --id Microsoft.DotNet.SDK.8 --exact --source winget }
    } else {
        Write-Host 'Install .NET 8 SDK manually: https://dotnet.microsoft.com/download/dotnet/8.0'
    }
}

if (Get-Command docker -ErrorAction SilentlyContinue) {
    Write-Host 'Docker CLI is installed. Confirm Docker Desktop is running with: docker info' -ForegroundColor Green
} else {
    Write-Warning 'Docker CLI was not found.'
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        $answer = Read-Host 'Install Docker Desktop using winget? (Y/N)'
        if ($answer -match '^(Y|YES)$') { winget install --id Docker.DockerDesktop --exact --source winget }
    } else {
        Write-Host 'Install Docker Desktop manually: https://www.docker.com/products/docker-desktop'
    }
}


# Azure Storage Explorer is used to inspect the event-banners container.
if (Get-Command winget -ErrorAction SilentlyContinue) {
    $storageExplorer = winget list --id Microsoft.AzureStorageExplorer --exact 2>$null
    if ($storageExplorer -match 'Azure Storage Explorer') {
        Write-Host 'Azure Storage Explorer appears to be installed.' -ForegroundColor Green
    } else {
    $answer = Read-Host 'Install Azure Storage Explorer using winget? (Y/N)'
    if ($answer -match '^(Y|YES)$') {
        winget install --id Microsoft.AzureStorageExplorer --exact --source winget
    }
    }
} else {
    Write-Host 'Install Azure Storage Explorer manually: https://azure.microsoft.com/products/storage/storage-explorer'
}

Write-Host ''
Write-Host 'After installation, close and reopen PowerShell, then run:' -ForegroundColor Yellow
Write-Host '  dotnet --list-sdks'
Write-Host '  dotnet restore RaceDay.sln'
Write-Host '  dotnet build RaceDay.sln --configuration Release'
Write-Host '  docker info'
