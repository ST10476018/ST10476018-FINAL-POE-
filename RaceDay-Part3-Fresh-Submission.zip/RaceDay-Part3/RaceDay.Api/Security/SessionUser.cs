using RaceDay.Api.Models;

namespace RaceDay.Api.Security;

public static class SessionUser
{
    public const string UserIdKey = "RaceDay.UserId";
    public const string RoleKey = "RaceDay.Role";
    public const string NameKey = "RaceDay.Name";
    public static int? Id(HttpContext context) => context.Session.GetInt32(UserIdKey);
    public static string? Role(HttpContext context) => context.Session.GetString(RoleKey);
    public static bool IsRole(HttpContext context, string role) => Id(context).HasValue && Role(context) == role;
}
