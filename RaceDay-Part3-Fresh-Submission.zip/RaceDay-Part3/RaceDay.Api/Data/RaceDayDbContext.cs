using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Models;

namespace RaceDay.Api.Data;

public sealed class RaceDayDbContext(DbContextOptions<RaceDayDbContext> options) : DbContext(options)
{
    public DbSet<ApplicationUser> Users => Set<ApplicationUser>();
    public DbSet<Event> Events => Set<Event>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<EventCategory> EventCategories => Set<EventCategory>();
    public DbSet<EventEnrolment> EventEnrolments => Set<EventEnrolment>();
    public DbSet<EventResult> EventResults => Set<EventResult>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<ApplicationUser>().HasIndex(x => x.Email).IsUnique();
        modelBuilder.Entity<ApplicationUser>().Property(x => x.Email).HasMaxLength(256).IsRequired();
        modelBuilder.Entity<ApplicationUser>().Property(x => x.FullName).HasMaxLength(120).IsRequired();
        modelBuilder.Entity<ApplicationUser>().Property(x => x.Role).HasMaxLength(20).IsRequired();
        modelBuilder.Entity<ApplicationUser>().Property(x => x.PasswordHash).IsRequired();
        modelBuilder.Entity<Event>().Property(x => x.Name).HasMaxLength(150).IsRequired();
        modelBuilder.Entity<Event>().Property(x => x.Location).HasMaxLength(200).IsRequired();
        modelBuilder.Entity<Event>().Property(x => x.EventType).HasMaxLength(10).IsRequired();
        modelBuilder.Entity<Event>().Property(x => x.BannerImageUrl).HasMaxLength(2048);
        modelBuilder.Entity<Event>().Property(x => x.DistanceKm).HasPrecision(8, 2);
        modelBuilder.Entity<Category>().Property(x => x.Name).HasMaxLength(100).IsRequired();
        modelBuilder.Entity<Category>().Property(x => x.DistanceKm).HasPrecision(8, 2);
        modelBuilder.Entity<EventCategory>().HasKey(x => new { x.EventId, x.CategoryId });
        modelBuilder.Entity<EventCategory>().HasOne(x => x.Event).WithMany(x => x.Categories).HasForeignKey(x => x.EventId).OnDelete(DeleteBehavior.Cascade);
        modelBuilder.Entity<EventCategory>().HasOne(x => x.Category).WithMany(x => x.EventCategories).HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<EventEnrolment>().HasIndex(x => new { x.ParticipantId, x.EventId }).IsUnique();
        modelBuilder.Entity<EventEnrolment>().HasOne(x => x.Participant).WithMany().HasForeignKey(x => x.ParticipantId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<EventEnrolment>().HasOne(x => x.Event).WithMany().HasForeignKey(x => x.EventId).OnDelete(DeleteBehavior.Cascade);
        modelBuilder.Entity<EventEnrolment>().HasOne(x => x.Category).WithMany().HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<EventResult>().HasIndex(x => new { x.EventId, x.ParticipantId }).IsUnique();
        modelBuilder.Entity<EventResult>().HasOne(x => x.Participant).WithMany().HasForeignKey(x => x.ParticipantId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<EventResult>().HasOne(x => x.Event).WithMany().HasForeignKey(x => x.EventId).OnDelete(DeleteBehavior.Cascade);
        modelBuilder.Entity<Event>().HasOne(x => x.Organizer).WithMany().HasForeignKey(x => x.OrganizerId).OnDelete(DeleteBehavior.Restrict);
    }
}
