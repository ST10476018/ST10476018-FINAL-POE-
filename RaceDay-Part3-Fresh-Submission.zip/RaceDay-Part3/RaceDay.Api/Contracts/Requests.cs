namespace RaceDay.Api.Contracts;

public sealed record RegisterRequest(string FullName, string Email, string Password, string Role);
public sealed record LoginRequest(string Email, string Password);
public sealed record UpdateProfileRequest(string FullName, string Email);
public sealed record EventRequest(string Name, string Description, DateTime EventDate, string Location, decimal DistanceKm, string EventType);
public sealed record CategoryRequest(string Name, string? AgeGroup, decimal? DistanceKm);
public sealed record EnrolRequest(int CategoryId);
public sealed record ResultRequest(int ParticipantId, string? FinishTime, int FinishPosition);
