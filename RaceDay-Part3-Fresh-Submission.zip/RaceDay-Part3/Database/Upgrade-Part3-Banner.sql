/* Run once against an existing Part 2 RaceDayDb database before using banner uploads. */
IF COL_LENGTH('dbo.Events', 'BannerImageUrl') IS NULL
BEGIN
    ALTER TABLE dbo.Events ADD BannerImageUrl nvarchar(2048) NULL;
END;
GO
