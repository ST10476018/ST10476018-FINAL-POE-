# RaceDay POE Part 3 — Submission Notes

**Student:** Siyanda Mkhize  
**Student number:** ST10476018  
**Project:** RaceDay Event Management System

## What this package provides

This source package contains an ASP.NET Core MVC front end (`RaceDay.Mvc`) that calls the REST API (`RaceDay.Api`), SQL scripts for the event banner URL property, Azure Blob Storage integration in the API, a Dockerfile for the MVC front end, a GitHub Actions workflow, and a step-by-step implementation guide covering all 11 requested topics.

## The 11 requested topics

1. Set up an Azure Blob Storage account.
2. Install Azure Storage Explorer.
3. Add image URL properties to the Events database table and API model.
4. Register and configure Azure Blob Storage services in the API.
5. Configure the blob container and upload behaviour.
6. Implement the event banner upload endpoint and MVC event upload actions.
7. Complete upload validation, ownership checks and error handling.
8. Update event create/edit views to accept banner files.
9. Save the blob URL to SQL Server and display it in event cards/details.
10. Install Docker Desktop.
11. Build and run the MVC application in Docker.

See `POE-Part3-Implementation-Guide.md` for the detailed procedure, code locations, commands and verification checklist.

## Important configuration boundary

Azure resources cannot be created inside a ZIP file. The student must sign in to the institution-approved Azure tenant and create or obtain access to a Storage account. The API must be configured locally with the Azure Storage connection string using .NET user-secrets. Never paste a password, connection string, access key or token into source code, README files, screenshots or GitHub.

The supplied Dockerfile packages the MVC web front end. The REST API and SQL Server are separate services in this demonstration and must be running/reachable when using the MVC container. Follow the README for the correct host URL.

## Verification status

The source archive structure and required project/documentation files have been inspected. A .NET build, database integration test, Azure upload test and Docker runtime test have **not** been performed in this environment. Do not report those tests as passed unless they are run successfully on the submission machine. The suggested Git commit sequence in README is a plan only; create actual commits in the student's GitHub repository and verify the Actions workflow there.
