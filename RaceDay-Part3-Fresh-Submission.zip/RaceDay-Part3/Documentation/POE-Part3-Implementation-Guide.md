# RaceDay POE Part 3 — Implementation Guide

**Student:** Siyanda Mkhize  
**Student number:** ST10476018  
**Project:** RaceDay event management system  
**Technology:** ASP.NET Core 8 MVC, ASP.NET Core REST API, SQL Server, Azure Blob Storage and Docker

> This guide documents the implementation sequence requested for Part 3. Azure resources, SQL Server, Docker Desktop, GitHub and the .NET SDK are external services/software. They must be installed, provisioned or configured on the student's machine/account. No school password, Azure connection string, storage key or other secret is included in this source code.

## Architecture overview

- **RaceDay.Mvc** is the browser-facing website. It calls the REST API using `RaceDayApiClient` and does not connect directly to SQL Server.
- **RaceDay.Api** owns the database operations, event banner upload endpoint and Azure Blob Storage SDK integration.
- **SQL Server** stores event data and the `BannerImageUrl` property. The actual image file is stored in Azure Blob Storage; only its URL is stored in SQL Server.
- **Dockerfile** builds and runs the MVC front end in a container. The API and SQL Server remain separate services in this demonstration setup.

## 1. Set up an Azure Blob Storage account

1. Open [https://portal.azure.com](https://portal.azure.com) and sign in using the student's own authorised school account. Never share the password in source code, screenshots, chat or GitHub.
2. Search for **Storage accounts**, choose **Create**, and select the subscription available to the student.
3. Create a resource group, for example `RaceDay-Resources`.
4. Enter a globally unique lowercase storage account name, for example `racedayst10476018` (Azure may require a different name if this one is unavailable).
5. Select an Azure region available to the subscription. Keep the recommended performance and redundancy settings unless the lecturer specifies otherwise.
6. Review the configuration and select **Create**.
7. When deployment completes, open the storage account. Under **Security + networking → Access keys**, reveal and copy a connection string for local development. Treat it as a password. Do not commit it to Git.

**If the school subscription does not permit creating a storage account:** ask the lecturer/IT administrator to enable the required Azure service or provide an approved storage account. Do not use another person's keys.

## 2. Install Azure Storage Explorer

1. Download **Azure Storage Explorer** from [https://azure.microsoft.com/products/storage/storage-explorer](https://azure.microsoft.com/products/storage/storage-explorer).
2. On Windows, you can also install it from PowerShell with `winget install --id Microsoft.AzureStorageExplorer --exact --source winget`.
3. Run the installer and complete the installation.
4. Open Storage Explorer and choose **Sign in with Azure**.
5. Sign in with the authorised school account and select the correct tenant/subscription.
6. Expand the storage account and open **Blob Containers**. After the first successful application upload, the `event-banners` container should appear.
7. If the account is not listed, use **Connect to Azure Storage → Storage account or service → Connection string** and paste the connection string locally. Do not save it in the repository or share it.

## 3. Add new image properties to the database

The API entity `RaceDay.Api/Models/Entities.cs` includes:

```csharp
public string? BannerImageUrl { get; set; }
```

The EF Core model configures the URL length in `RaceDay.Api/Data/RaceDayDbContext.cs`:

```csharp
modelBuilder.Entity<Event>().Property(x => x.BannerImageUrl).HasMaxLength(2048);
```

For an existing Part 2 database, open `Database/Upgrade-Part3-Banner.sql` in SQL Server Management Studio, select the `RaceDayDb` database and execute the script once. It adds the nullable `BannerImageUrl` column to the Events table. For a new database, use `Database/RaceDaySchema.sql`, which already includes the property. Back up the database before running schema changes.

## 4. Add Blob Storage services

The API project references the Azure SDK package `Azure.Storage.Blobs`. The API reads settings from configuration and registers `BlobServiceClient` only when a connection string is supplied. This is intentionally API-side: the MVC application must never receive the storage account key.

Local development configuration is supplied through .NET user-secrets from the solution directory:

```powershell
dotnet user-secrets init --project RaceDay.Api
dotnet user-secrets set "AzureBlobStorage:ConnectionString" "YOUR_STORAGE_CONNECTION_STRING" --project RaceDay.Api
dotnet user-secrets set "AzureBlobStorage:ContainerName" "event-banners" --project RaceDay.Api
```

Replace the placeholder locally; do not paste the real value into this guide. `RaceDay.Api/appsettings.json` contains the non-secret container name only.

## 5. Complete Blob Storage configuration and service behaviour

The API uses `BlobServiceClient` to:

1. Get the configured `event-banners` container.
2. Create the container if it does not exist.
3. Create a unique blob name for each upload to avoid overwriting another event image.
4. Upload the image stream with its image content type.
5. Save the resulting blob URL to `Event.BannerImageUrl` in SQL Server.

The sample currently requests blob-level public read access so the browser can display the image URL without a separate sign-in. Some Azure accounts disable public blob access. If Azure rejects this setting, the storage account policy must be checked with the administrator; alternatively, implement a private-container SAS/proxy image delivery design. Do not weaken a school tenant policy without approval.

## 6. Events controller / banner upload endpoint

The MVC event-management actions are in `RaceDay.Mvc/Controllers/OrganizerController.cs`. The `Create` and `Edit` actions accept an optional `IFormFile` and pass it to the API through `RaceDayApiClient.UploadBannerAsync`.

The API upload route is `POST /api/events/{id}/banner` in `RaceDay.Api/Program.cs`. It:

- Requires an authenticated **Organizer** session.
- Checks that the event exists and belongs to that organiser.
- Requires multipart form data with the file field named `file`.
- Rejects empty files and files larger than 5 MB.
- Accepts JPG/JPEG, PNG and WEBP content types only.
- Uploads the file to Azure Blob Storage and updates `BannerImageUrl` in the database.

The MVC front end does not upload directly to Azure and does not contain the storage connection string.

## 7. Complete and verify the Events upload flow

1. Start SQL Server and ensure the Part 2 database is available.
2. Apply `Database/Upgrade-Part3-Banner.sql` if this is an existing Part 2 database.
3. Configure the API database connection string using the Part 2 setup instructions. If LocalDB is not available on the machine, use an installed SQL Server instance and update the connection string accordingly.
4. Configure Azure Blob Storage using the user-secrets commands in Step 4.
5. Start the API and register/log in as an Organizer.
6. Create an event and select a JPG, PNG or WEBP banner smaller than 5 MB.
7. Confirm that the API returns a `BannerImageUrl`, that the database row contains the URL, and that the blob appears in Storage Explorer.
8. Test an unsupported file type and a file larger than 5 MB; the API should reject them.

## 8. Update the Events views

`RaceDay.Mvc/Views/Organizer/Create.cshtml` and `Edit.cshtml` use `enctype="multipart/form-data"` and provide an image file input. The views show the existing banner preview when `BannerImageUrl` is populated. Event cards and participant event details also render the banner URL where available.

When editing an event, leaving the file input empty keeps the existing banner URL. Selecting a new file uploads a replacement image and updates the event's stored URL.

## 9. Save the image URL and display it in details views

The database stores only `BannerImageUrl`; it does not store the binary image. The uploaded image is stored in Blob Storage. The participant event list and event details views use the saved URL in an HTML `<img>` element. Verify all three locations:

- The blob exists in the `event-banners` container.
- The corresponding Events database row has a `BannerImageUrl` value.
- The image displays in the organiser edit page and participant event pages.

If the URL is not reachable, check the container access policy, account public-access policy, URL and browser network errors.

## 10. Install Docker Desktop

1. Check that the laptop meets the current Docker Desktop requirements and that hardware virtualisation is enabled.
2. Download Docker Desktop from [https://www.docker.com/products/docker-desktop](https://www.docker.com/products/docker-desktop).
3. Install Docker Desktop, using the WSL 2 backend where supported.
4. Restart Windows if the installer requests it, open Docker Desktop and wait until it reports that the engine is running.
5. In PowerShell, verify installation:

```powershell
docker --version
docker info
```

Docker Desktop licensing and installation may be governed by the institution's policies. The included `scripts/setup-tools.ps1` can attempt installation through Windows Package Manager (`winget`) where available.

## 11. Build and run the application through Docker

The supplied Dockerfile builds the MVC project only. Start the API and SQL Server separately, then build the MVC container from the directory containing `Dockerfile`:

```powershell
docker build -t raceday-mvc:part3 .
docker run --name raceday-mvc -p 8080:8080 -e Api__BaseUrl=http://host.docker.internal:5142 raceday-mvc:part3
```

Open [http://localhost:8080](http://localhost:8080). The API must be listening on the host at port `5142`; `host.docker.internal` allows the container to reach the host machine. If the API runs at another address, change `Api__BaseUrl`. Stop and remove the container with:

```powershell
docker stop raceday-mvc
docker rm raceday-mvc
```

For a repeat run after the container has been removed, run the `docker run` command again. If a container with that name already exists, remove it first.

## Local SDK installation helper

Run PowerShell as a normal user and execute `scripts/setup-tools.ps1`. It checks for .NET 8 and Docker, and offers `winget` installation if either is missing. You can also install the .NET 8 SDK manually from [https://dotnet.microsoft.com/download/dotnet/8.0](https://dotnet.microsoft.com/download/dotnet/8.0). Verify with:

```powershell
dotnet --list-sdks
dotnet restore RaceDay.sln
dotnet build RaceDay.sln --configuration Release
dotnet test RaceDay.sln --configuration Release
```

## Final verification and evidence checklist

- [ ] .NET 8 SDK installed and `dotnet --list-sdks` shows an 8.0 SDK.
- [ ] SQL Server database is created and Part 3 banner column upgrade applied.
- [ ] Azure Storage account and `event-banners` container configured.
- [ ] Azure connection string stored in API user-secrets, not source control.
- [ ] Organizer can create/edit an event and upload a valid banner.
- [ ] Blob appears in Storage Explorer and URL is saved in SQL Server.
- [ ] Participant can see event banner in event listing and details.
- [ ] API authentication and role restrictions verified.
- [ ] MVC/API solution builds and tests pass on the submission machine.
- [ ] Docker image builds and the container website opens.
- [ ] GitHub repository contains actual meaningful commits and Actions workflow has run successfully.
- [ ] Unlisted demonstration video recorded and its real URL added to the submission/README.

**Academic integrity / evidence note:** This source package includes implementation and instructions, not proof that cloud resources were created, Docker was installed, GitHub commits were pushed, tests passed or a video was recorded. Capture your own screenshots and provide genuine evidence for work completed in your accounts.
